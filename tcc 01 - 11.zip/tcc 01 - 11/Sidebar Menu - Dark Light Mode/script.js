function toggleContent(contentName) {
    var contents = document.getElementsByClassName('page-content')
    var content = document.querySelector('#' + contentName + '-content')

    Array.from(contents).forEach((c) => {
        c.style.display = 'none'
    })

    content.style.display = 'block'
}